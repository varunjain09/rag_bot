# -*- coding: utf-8 -*-
# Streamlit-based RAG Bot with FAISS and Transformer Models

# 1. Install dependencies (Run in Colab or locally before running Streamlit)
# !pip install streamlit transformers sentence-transformers faiss-cpu newspaper3k pdfplumber pytesseract pdf2image sqlalchemy pymysql

import streamlit as st

# Attempt to import all libraries with fallbacks
try:
    import os
    import torch
    import faiss
    import numpy as np
    import pandas as pd
    from newspaper import Article
    from sqlalchemy import create_engine
    import pickle
    from sentence_transformers import SentenceTransformer
    from transformers import AutoModelForCausalLM, AutoTokenizer, pipeline
    all_libs_loaded = True
except ImportError as e:
    st.error(f"❌ Required library missing: {e.name}. Please install all dependencies.")
    all_libs_loaded = False

# Optional OCR dependencies
try:
    import pytesseract
    from pdf2image import convert_from_path
    import pdfplumber
    OCR_AVAILABLE = True
except ImportError:
    OCR_AVAILABLE = False
    st.warning("⚠️ OCR features are disabled. Missing: pytesseract/pdfplumber/pdf2image")

# Only proceed if all libraries are loaded
if all_libs_loaded:

    # Model Options
    llm_options = {
        "Mistral 7B Instruct": "mistralai/Mistral-7B-Instruct-v0.1",
        "Falcon RW 1B": "tiiuae/falcon-rw-1b"
    }

    # Globals
    rag_pipeline = None
    embedder = None
    hf_token = "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"
    all_chunks, all_embeddings, chat_history = [], [], []
    index = None

    # Load LLM
    @st.cache_resource
    def load_llm(repo):
        tokenizer = AutoTokenizer.from_pretrained(repo, use_auth_token=hf_token)
        model = AutoModelForCausalLM.from_pretrained(
            repo, use_auth_token=hf_token,
            device_map="auto",
            torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32
        )
        return pipeline("text-generation", model=model, tokenizer=tokenizer)

    # Load embedder
    @st.cache_resource
    def load_embedder():
        return SentenceTransformer("all-MiniLM-L6-v2", use_auth_token=hf_token)

    # File utilities
    def extract_text_pdf(file):
        if OCR_AVAILABLE:
            try:
                with pdfplumber.open(file) as pdf:
                    return "\n".join(page.extract_text() or "" for page in pdf.pages)
            except:
                return "\n".join(pytesseract.image_to_string(img) for img in convert_from_path(file))
        else:
            return "OCR not available. Please install pytesseract and pdf2image."

    def extract_article_text(url):
        article = Article(url)
        article.download()
        article.parse()
        return article.text

    def load_dataframe(file):
        if file.name.endswith(".csv"):
            return pd.read_csv(file)
        return pd.read_excel(file)

    def load_rdbms_table(conn, table):
        engine = create_engine(conn)
        df = pd.read_sql_table(table, engine)
        return df

    def dataframe_to_chunks(df):
        return ["; ".join(f"{k}: {v}" for k, v in row.items()) for _, row in df.iterrows()]

    def embed_chunks(text_chunks):
        return embedder.encode(text_chunks, convert_to_tensor=False)

    def build_faiss_index(embeds):
        idx = faiss.IndexFlatL2(embeds.shape[1])
        idx.add(embeds)
        return idx

    def search_faiss(query, k=3):
        qvec = embedder.encode([query]).astype("float32")
        D, I = index.search(qvec, k)
        return [all_chunks[i] for i in I[0]]

    def ask_question(query):
        top = search_faiss(query)
        context = "\n\n".join(top + [f"Q: {q}\nA: {a}" for q, a in chat_history[-3:]])
        prompt = f"[INST] Use the context below to answer the question.\n\n{context}\n\nQuestion: {query} [/INST]"
        result = rag_pipeline(prompt, max_new_tokens=150, do_sample=True, temperature=0.7)
        ans = result[0]['generated_text'].replace(prompt, '').strip()
        chat_history.append((query, ans))
        return ans

    # Streamlit UI
    st.set_page_config(page_title="RAG Bot", layout="wide")
    st.title("🧠 Retrieval-Augmented Generation Chatbot")

    with st.sidebar:
        model_choice = st.selectbox("Choose LLM", list(llm_options.keys()))
        if st.button("Load Model"):
            rag_pipeline = load_llm(llm_options[model_choice])
            st.success(f"Model {model_choice} loaded!")
        if embedder is None:
            embedder = load_embedder()

    # File upload (PDF)
    uploaded_pdf = st.file_uploader("Upload PDF", type="pdf")
    if uploaded_pdf:
        text = extract_text_pdf(uploaded_pdf)
        chunks = [text[i:i+512] for i in range(0, len(text), 512)]
        embeds = embed_chunks(chunks)
        all_chunks.extend(chunks)
        all_embeddings.extend(embeds)
        index = build_faiss_index(np.vstack(all_embeddings).astype("float32"))
        st.success("PDF ingested and indexed.")

    # File upload (CSV/XLSX)
    uploaded_data = st.file_uploader("Upload CSV/XLSX", type=["csv", "xlsx"])
    if uploaded_data:
        df = load_dataframe(uploaded_data)
        chunks = dataframe_to_chunks(df)
        embeds = embed_chunks(chunks)
        all_chunks.extend(chunks)
        all_embeddings.extend(embeds)
        index = build_faiss_index(np.vstack(all_embeddings).astype("float32"))
        st.success("DataFrame ingested and indexed.")

    # URL ingestion
    url = st.text_input("Ingest from URL")
    if st.button("Load URL") and url:
        text = extract_article_text(url)
        chunks = [text[i:i+512] for i in range(0, len(text), 512)]
        embeds = embed_chunks(chunks)
        all_chunks.extend(chunks)
        all_embeddings.extend(embeds)
        index = build_faiss_index(np.vstack(all_embeddings).astype("float32"))
        st.success("URL ingested and indexed.")

    # SQL ingestion
    with st.expander("Ingest from SQL Database"):
        conn_str = st.text_input("Connection String")
        table_name = st.text_input("Table Name")
        if st.button("Ingest SQL Table"):
            df = load_rdbms_table(conn_str, table_name)
            chunks = dataframe_to_chunks(df)
            embeds = embed_chunks(chunks)
            all_chunks.extend(chunks)
            all_embeddings.extend(embeds)
            index = build_faiss_index(np.vstack(all_embeddings).astype("float32"))
            st.success("SQL table ingested.")

    # Ask questions
    query = st.text_input("Ask a question:")
    if st.button("Get Answer") and query:
        if rag_pipeline is None:
            st.error("Please load a model first.")
        elif index is None:
            st.error("Please ingest data first.")
        else:
            answer = ask_question(query)
            st.success(answer)

    # Chat history
    with st.expander("Chat History"):
        for i, (q, a) in enumerate(chat_history[-5:], 1):
            st.markdown(f"**{i}. Q: {q}**\n- A: {a}")